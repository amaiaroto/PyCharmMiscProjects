# Credits and Attributes
# credit to rizal2109 on flaticon.com for chess-icon.png
# credit to all the authors of the unused assets

import os
import sys
from contextlib import redirect_stdout

with redirect_stdout(open(os.devnull, 'w')):
    import pygame as pg

from Chess.Screen import Screen
from Chess.Pieces import Piece

pg.init()

screen = Screen(pg, 800, 800).screen()
pg.display.set_icon(pg.image.load('chess-icon.png'))
pg.display.set_caption('Chess')

while True:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()

    screen.fill((255, 255, 255))

    text = (pg.font.SysFont(None, 72, True)
            .render('Hello! Did I do a good job?', False, (0, 0, 0)))
    screen.blit(text, (400 - text.get_rect().centerx, 400 - text.get_rect().centery))

    pg.display.flip()
